export CC=/usr/bin/cc
export CPPFLAGS=-DIBMR2Fortran
export FC=xlf
export F90=xlf90
export F90FLAGS=-qsuffix=cpp=f90
export LIBS='-lSystemStubs'

configure --prefix=/Users/spiga/mac/new/netcdf/install

make
make test
make install
make clean
